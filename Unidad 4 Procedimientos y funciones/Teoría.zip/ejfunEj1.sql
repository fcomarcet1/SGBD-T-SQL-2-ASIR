/*Crear una función escalar para la base de datos clínica,
 que calcule el importe total con IVA  de cada una de las visitas del 
 paciente código 6.
*/

CREATE FUNCTION CalcularImporte( @codpac smallint)
RETURNS decimal(6,2)
AS
BEGIN
	Declare @importeTotal decimal(6,2) 
	
	SELECT @importeTotal= SUM(importe)*1.21
    from Visitas where [CODIGO PACIENTE]=@codpac
	
   RETURN @importeTotal
END
-- ---------------------------------------------------------------------------
Declare @codP smallint, @nombre nvarchar(30)
declare @impTotal decimal(6,2)

set @codP=6
select @nombre=nombre from pacientes
where CODIGO=@codP

set @impTotal=dbo.CalcularImporte(@codP) -- llamada a la función

print 'El paciente '+@nombre+' se ha gastado '+cast(@impTotal as nvarchar)
